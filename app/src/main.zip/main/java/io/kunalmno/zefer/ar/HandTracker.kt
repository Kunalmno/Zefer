package io.kunalmno.zefer.ar

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.SystemClock
import android.util.Log
import androidx.camera.core.ImageProxy
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** A landmark. x/y are 0..1 inside the upright (and, for the front camera, mirrored) camera frame. */
data class Pt(val x: Float, val y: Float, val z: Float)

data class TrackedHand(
    /** "Left" / "Right" as reported by MediaPipe (selfie convention). Raw – stage 2 will double-check it. */
    val label: String,
    val score: Float,
    /** 21 normalized landmarks (see MediaPipe hand landmark indices: 0 wrist, 4/8/12/16/20 fingertips). */
    val points: List<Pt>,
    /** 21 landmarks in metres, origin at the hand centre – used later for tilt estimation. */
    val world: List<Pt>
)

data class HandFrame(
    val hands: List<TrackedHand> = emptyList(),
    /** Size of the upright frame the landmarks refer to. */
    val width: Int = 0,
    val height: Int = 0
)

/**
 * Wraps MediaPipe's Hand Landmarker (runs fully on the phone).
 * Feed it camera frames with [analyze]; read results from [frame].
 */
class HandTracker(context: Context) : AutoCloseable {

    private val lock = Any()
    @Volatile private var closed = false
    private var lastTimestamp = 0L

    private val _frame = MutableStateFlow(HandFrame())
    val frame: StateFlow<HandFrame> = _frame.asStateFlow()

    private val _fps = MutableStateFlow(0)
    val fps: StateFlow<Int> = _fps.asStateFlow()

    private var fpsCount = 0
    private var fpsWindowStart = SystemClock.uptimeMillis()

    /** "GPU" or "CPU" – whichever delegate could be created. */
    val delegateName: String

    private val landmarker: HandLandmarker

    init {
        var name = "GPU"
        landmarker = try {
            build(context, Delegate.GPU)
        } catch (e: Exception) {
            Log.w(TAG, "GPU delegate failed, falling back to CPU", e)
            name = "CPU"
            build(context, Delegate.CPU)
        }
        delegateName = name
    }

    private fun build(context: Context, delegate: Delegate): HandLandmarker {
        val base = BaseOptions.builder()
            .setModelAssetPath(MODEL_ASSET)
            .setDelegate(delegate)
            .build()
        val options = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(base)
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setNumHands(2)
            .setMinHandDetectionConfidence(0.5f)
            .setMinHandPresenceConfidence(0.5f)
            .setMinTrackingConfidence(0.5f)
            .setResultListener { result, image -> onResult(result, image) }
            .setErrorListener { e -> Log.e(TAG, "MediaPipe error", e) }
            .build()
        return HandLandmarker.createFromOptions(context, options)
    }

    /**
     * Call from the CameraX analyzer thread. Closes the [proxy] itself.
     * @param mirror true for the front camera, so the frame matches the mirrored preview
     *               (this also makes MediaPipe's Left/Right labels match the user's real hands).
     */
    fun analyze(proxy: ImageProxy, mirror: Boolean) {
        try {
            if (closed) return
            val source = proxy.toBitmap()
            val matrix = Matrix().apply {
                postRotate(proxy.imageInfo.rotationDegrees.toFloat())
                if (mirror) postScale(-1f, 1f)
            }
            val upright = Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
            val image = BitmapImageBuilder(upright).build()

            synchronized(lock) {
                if (closed) return
                val timestamp = maxOf(SystemClock.uptimeMillis(), lastTimestamp + 1)
                lastTimestamp = timestamp
                landmarker.detectAsync(image, timestamp)
            }
        } catch (e: Exception) {
            Log.e(TAG, "analyze failed", e)
        } finally {
            proxy.close()
        }
    }

    private fun onResult(result: HandLandmarkerResult, image: MPImage) {
        val hands = result.landmarks().indices.map { i ->
            val category = result.handednesses().getOrNull(i)?.firstOrNull()
            TrackedHand(
                label = category?.categoryName() ?: "?",
                score = category?.score() ?: 0f,
                points = result.landmarks()[i].map { Pt(it.x(), it.y(), it.z()) },
                world = result.worldLandmarks().getOrNull(i)?.map { Pt(it.x(), it.y(), it.z()) } ?: emptyList()
            )
        }
        _frame.value = HandFrame(hands, image.width, image.height)

        fpsCount++
        val now = SystemClock.uptimeMillis()
        if (now - fpsWindowStart >= 1000) {
            _fps.value = fpsCount
            fpsCount = 0
            fpsWindowStart = now
        }
    }

    override fun close() {
        synchronized(lock) {
            if (closed) return
            closed = true
            landmarker.close()
        }
    }

    companion object {
        private const val TAG = "HandTracker"
        /** Put the model in app/src/main/assets/ (download link in the setup notes). */
        const val MODEL_ASSET = "hand_landmarker.task"
    }
}
